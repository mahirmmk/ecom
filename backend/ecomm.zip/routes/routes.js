const express=require("express");
const productRouter=express.Router();
const pController=require("../controllers/productController")
productRouter.get("/getProducts", pController.getProducts);
productRouter.post("/postProduct",pController.postProduct);
productRouter.get("/editProduct/:id", pController.editProduct);
productRouter.patch("/patchProduct/:id",pController.patchProduct);
productRouter.delete("/deleteProduct/:id", pController.deleteProduct);

module.exports=productRouter;