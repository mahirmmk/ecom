const express=require("express");
const app=express();
app.use(express.json());
require("dotenv").config()
const port=process.env.PORT;
require("./utilities/productDb");

const alternatePort=3001




const productRouter=require("./routes/routes")
app.use("/" ,productRouter);

app.listen(`${port}`, ()=> console.log("the server is listening at "+ port));
