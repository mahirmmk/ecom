const express=require("express");
const app=express();
app.use(express.json());
require("dotenv").config();

const mongoose=require("mongoose");

mongoose.connect(`${process.env.mongoDBURL}/${process.env.database}`).then(connect=>{
    console.log("connected to mongoDB at "+ process.env.mongoDBURL+"/"+process.env.database )}).catch(err=>console.log(err));

const router=require("./routes/routes")
// app.use("/" ,router);
app.get("/getProducts", (req, res)=>{
    
})


const productSchema=mongoose.Schema({
    title:{type:String, required:true},
    category:{type:String, required:true},
    price:{type:String, required:true},
    description:{type:String, required:true},
    imageURL:{type:String, required:false},
    addBy:{type:String, required:false}
});
const collection=mongoose.model("collection", productSchema);

app.post("/postProduct",(req,res)=>{
    const{title,category,price,description,imageURL,addBy}=req.body;
    product.create({title:title,category:category,price:price,description:description,imageURL:imageURL,addBy:addBy}).then(res.send({
        dataCreated:req.body,
        message:"YOUR DATA HAS BEEN UPDATED SUCCESSFULLY"
    
    }).status(201).end()).catch(err=> console.log(err))
}
)

app.get("/getProduct", (req, res)=>{
    collection.find().then(data=>{
        res.status(200).json({
            succcess:true,
            message:"here is requested data",
            userdata:data
        })
    })

});


app.listen(`${process.env.PORT}`, ()=> console.log("the server is listening at "+ process.env.PORT));
